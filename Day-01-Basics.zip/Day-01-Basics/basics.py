# Basic input, variables, data types and calculations

name = input("Enter your name: ")
age = int(input("Enter your age: "))
college = input("Enter your college name: ")
cgpa = float(input("Enter your CGPA: "))

print("Name:", name)
print("Age:", age)
print("College:", college)
print("CGPA:", cgpa)

# Celsius to Fahrenheit
celsius = float(input("Celsius: "))
fahrenheit = celsius * 9 / 5 + 32
print("Fahrenheit:", fahrenheit)

# Gross salary
salary = int(input("Basic salary: "))
hra = int(input("HRA: "))
da = int(input("DA: "))
gross_salary = salary + hra + da
print("Gross salary:", gross_salary)

# Product bill
product_name = input("Product name: ")
price = float(input("Original price: "))
discount = float(input("Discount percentage: "))
discount_amount = price * discount / 100
final_price = price - discount_amount
print("Final price:", final_price)
