# Day 01 — Basics

## Python Learning Journey

This is Day 01 of my Python learning journey.

### What I practiced
- Basics
- Writing and running Python programs
- Problem-solving through practical exercises

### Files
The Python source files for this day's practice are in this folder.

### Progress
Continuing my journey from Python fundamentals toward advanced problem-solving.
