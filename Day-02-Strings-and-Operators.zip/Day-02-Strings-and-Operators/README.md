# Day 02 — Strings and Operators

## Python Learning Journey

This is Day 02 of my Python learning journey.

### What I practiced
- Strings and Operators
- Writing and running Python programs
- Problem-solving through practical exercises

### Files
The Python source files for this day's practice are in this folder.

### Progress
Continuing my journey from Python fundamentals toward advanced problem-solving.
