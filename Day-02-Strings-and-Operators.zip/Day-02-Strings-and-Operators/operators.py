# Arithmetic, comparison and logical operators

num1 = int(input("Select a number: "))
num2 = int(input("Select another number: "))

print("Greater:", num1 > num2)
print("Smaller:", num1 < num2)
print("Equal:", num1 == num2)
print("Both greater than 10:", num1 > 10 and num2 > 10)
print("At least one greater than 10:", num1 > 10 or num2 > 10)
print("num1 is not greater than 10:", not (num1 > 10))

# Two-digit number
num = int(input("Enter a two-digit number: "))
tens_digit = num // 10
ones_digit = num % 10
print("Tens digit:", tens_digit)
print("Ones digit:", ones_digit)
print("Sum of digits:", tens_digit + ones_digit)

# Seconds conversion
seconds = int(input("Enter seconds: "))
minutes = seconds // 60
remaining_seconds = seconds % 60
print("Minutes:", minutes)
print("Remaining seconds:", remaining_seconds)
