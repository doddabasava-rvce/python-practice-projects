# String practice: concatenation, methods, length, indexing and slicing

first_name = input("First name: ")
last_name = input("Last name: ")
full_name = first_name + " " + last_name

print("Full name:", full_name)
print("Uppercase:", full_name.upper())
print("Lowercase:", full_name.lower())
print("Length:", len(full_name))

word = input("Write a word: ")
print("First character:", word[0])
print("Last character:", word[-1])
print("First three characters:", word[:3])
print("Reversed:", word[::-1])

birth_year = input("Birth year: ")
username = first_name.lower() + last_name[0] + birth_year[-2:]
print("Username:", username)
